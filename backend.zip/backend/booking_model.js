

const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  username: String,
  phoneNumber: String,
  email: String,
  guestSize: Number,
  tourName: String,
  bookDate: Date,
  // You can add more fields as needed
});

module.exports = mongoose.model('Booking', bookingSchema);
