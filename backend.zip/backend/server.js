const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const cors = require('cors')
const app = express();
// require('dotenv').config();

// // Access environment variables
// const dbHost = process.env.DB_HOST;
// const dbPort = process.env.DB_PORT;
// const secretKey = process.env.SECRET_KEY;

// Import the Booking model
const Booking = require('./booking_model');


app.use(cors());
app.use(bodyParser.json());
mongoose.connect('mongodb://127.0.0.1:27017/tour');
const UserSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String,
    password2: String,
});


const User = mongoose.model('User', UserSchema);
app.post('/signup', async (req, res) => {
    try {
        const { username, email, password, password2 } = req.body;
        let hash; // Define hash in the outer scope

        bcrypt.genSalt(10, async (err, salt) => {
            if (err) {
                // Handle the error
                console.error('Error generating salt:', err);
            } else {
                try {
                    const hashedPassword = await bcrypt.hash(password, salt);
                    // Store the 'hashedPassword' in your database or use it as needed
                    hash = hashedPassword; // Assign the hashed password to hash
                    console.log('Hashed password:', hash);

                    // Now you can use 'hash' to create a new user
                    if (password == password2) {
                        const newUser = new User({ username, email, password: hash, password2:hash });
                        await newUser.save();
                        res.status(201).json({ message: 'User signed up successfully.' });
                    } 
                } catch (error) {
                    // Handle any errors that occur during hashing or user creation
                    console.error('Error:', error);
                    res.status(500).json({ error: 'An error occurred.' });
                }
            }
        });
    } catch (error) {
        res.status(500).json({ error: 'An error occurred.' });
        console.error(error);
    }
});


app.post('/login', async (req, res) => {

    try {
        const { username, password } = req.body;
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(401).json({ error: 'User not found.' });
        }
        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return res.status(401).json({ error: 'Invalid password.' });
        }
        
        res.json({ message: 'Login successful.' });
    } catch (error) {
        res.status(500).json({ error: 'An error occurred.' });
    }
});


app.post('/book', async (req, res) => {
  try {
    const { username, phoneNumber, email, guestSize, tourName } = req.body;

    // Check if the user is logged in (similar to your previous code)
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(401).json({ error: 'User not found. Please sign in or create an account.' });
    }

    // Create a new booking document and save it to the database
    const booking = new Booking({
      username,
      phoneNumber,
      email,
      guestSize,
      tourName,
    });

    await booking.save();

    res.json({ message: 'Booking successful.' });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred.' });
  }
});

  
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
