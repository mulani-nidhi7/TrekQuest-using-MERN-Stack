// src/components/LoginForm.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

//import LoginBg from 'C:\\Users\\Nidhi\\Desktop\\project_individual\\project_individual\\tours_and_travels\\toursandtravel\\src\\Components\\loginbg1.jpeg'

function LoginForm() {
  const navigate = useNavigate();

  // State to store form data
  // const [formData, setFormData] = useState(initialFormData);

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');



  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/login', {
        username,
        password,
      });
      console.log('Response from server:', response);

      if (response.status === 200) {
        // Handle successful login here
        alert('Login successful.');
        setUsername('');
        setPassword('');
        navigate('/');
      } else {
        // Handle other response status codes (e.g., 401 for authentication failure)
        alert('Login failed. Check your credentials.');
      }
    } catch (error) {
      console.error('Error logging in:', error);
      alert('Login failed.');
    }

  };

  const backgroundImageStyle = {
    //http://bit.ly/2gPLxZ4
    //https://fliphtml5.com/learning-center/wp-content/uploads/2016/11/promote-travel-and-tourism-companies-online-7.png
    backgroundImage: 'url("https://images.unsplash.com/photo-1606744666360-2f22c8b4a45b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1528&q=80")',
    //backgroundImage: `url(${LoginBg })`,
    backgroundSize: 'cover', // Optional: Adjust the background image size
    backgroundPosition: 'center', // Optional: Adjust the background image position
    height: '100vh', // Optional: Set a specific height for the container
  };

  const textcolor = {
    color: '#000080'
  }

  return (
    <div className="h-screen font-sans login" style={backgroundImageStyle}>
      <div className="container mx-auto h-full flex flex-1 justify-center items-center">
        <div className="w-full max-w-lg">
          <div className="leading-loose">
            <form
              className="max-w-sm m-4 p-10 bg-white bg-opacity-25 rounded shadow-xl"
              onSubmit={handleLogin}
            >
              <p className="text-white font-medium text-center text-xl font-bold" style={{ color: '#000080' }} >LOGIN</p>
              <div className="">
                <label className="block text-md " style={textcolor} htmlFor="email">
                  Username
                </label>
                <input
                  className="w-full px-5 py-1 text-gray-700 bg-gray-300 rounded focus:outline-none focus:bg-white"
                  type="text"
                  name="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="john@gmail.com"
                  required
                />
              </div>
              <div className="mt-2">
                <label className="block text-md " style={textcolor} >Password</label>
                <input
                  className="w-full px-5 py-1 text-gray-700 bg-gray-300 rounded focus:outline-none focus:bg-white"
                  type="password"
                  name="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="enter password"
                  aria-label="password"
                  required
                />
              </div>

              <div className="mt-4 items-center flex justify-between">
                <button
                  className="px-32 py-1 text-white font-light tracking-wider bg-gray-900 hover:bg-gray-800 rounded"
                  type="submit" 
                >
                  Submit
                </button>
              </div>
              <div className="text-right">
                Not a user?{' '}
                <a
                  className="inline-block right-0 align-baseline font-dark text-sm text-500 hover:text-red-400"
                  href="/signup"
                >
                  Sign Up
                </a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}


export default LoginForm;