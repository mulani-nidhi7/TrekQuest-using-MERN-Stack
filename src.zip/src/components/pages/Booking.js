import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Booking() 
{

   const navigate = useNavigate();
   const [username, setUsername] = useState('');
   const [email, setEmail] = useState('');
   const [phoneNumber, setPhoneNumber] = useState('');
   const [guestSize, setguestSize] = useState('');
   const [tourName,setTourname]=useState('');
   const [bookDate,setBookDate]=useState(null);
const handleBooking = async (e) => {

   e.preventDefault();
   try {
     const response = await axios.post('http://localhost:5000/book', {
       username,
       phoneNumber,
       email,
       guestSize,
       tourName,
       bookDate,
     });
 
     if (response.status === 200) {
       // Handle successful booking here
       alert('Booking successful.');

       // You can also navigate to a booking confirmation page or perform other actions
     } else {
       // Handle other response status codes (e.g., 401 for user not found)
       alert('Booking failed. Please sign in or create an account.');
     }
   } catch (error) {
     console.error('Error booking:', error);
     alert('Booking failed.');
     navigate('/login');
   }
 };
 
 return (
   <div className="grid min-h-screen place-items-center">
     <div className="w-11/12 p-12 bg-white sm:w-8/12 md:w-1/2 lg:w-5/12">
     
     
       <form className="mt-6" onSubmit={handleBooking}>
         <div className="flex justify-between gap-3">
           <span className="w-1/2">
             <label htmlFor="firstname" className="block text-xs font-semibold text-gray-600 uppercase">
               Username
             </label>
             <input
               id="username"
               type="text"
               name="username"
               
               onChange={(e) => setUsername(e.target.value)}
               placeholder="John"
               autoComplete="given-name"
               className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner"
               required
             />
           </span>
           <span className="w-1/2">
             <label htmlFor="lastname" className="block text-xs font-semibold text-gray-600 uppercase">
               Lastname
             </label>
             <input
               id="tourname"
               type="text"
               name="tourName"
               onChange={(e) => setTourname(e.target.value)}
               placeholder="Tourname"
               autoComplete="family-name"
               className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner"
               required
             />
           </span>
         </div>
         <label htmlFor="email" className="block mt-2 text-xs font-semibold text-gray-600 uppercase">
           E-mail
         </label>
         <input
           id="email"
           type="email"
           name="email"
           onChange={(e) => setEmail(e.target.value)}
           placeholder="john.doe@company.com"
           autoComplete="email"
           className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner"
           required
         />
         <label htmlFor="password" className="block mt-2 text-xs font-semibold text-gray-600 uppercase">
           phoneNumber
         </label>
         <input
           id="phone"
           type='number'
           name="phoneNumber"
           onChange={(e) => setPhoneNumber(e.target.value)}
           placeholder="********"
           autoComplete="new-password"
           className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner"
           required
         />
         <label
           htmlFor="password-confirm"
           className="block mt-2 text-xs font-semibold text-gray-600 uppercase"
         >
           bookDate
         </label>
         <input
           id="password-confirm"
           type="date"
           name="bookDate"
           onChange={(e) => setBookDate(e.target.value)}
           placeholder=""
           autoComplete="new-password"
           className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner"
           required
         />
         <label htmlFor="guestSize" className="block mt-2 text-xs font-semibold text-gray-600 uppercase">
           Guest Size
         </label>
         <input
           id="guestSize"
           type="number"
           name="guestSize"
           onChange={(e) => setguestSize(e.target.value)}
           placeholder="0"
           className="block w-full p-3 mt-2 text-gray-700 bg-gray-200 appearance-none focus:outline-none focus:bg-gray-300 focus:shadow-inner"
           required
         />
         <button
           type="submit"
           className="w-full py-3 mt-6 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"
         >
           Book Now
         </button>
         {/* <p className="flex justify-between inline-block mt-4 text-xs text-gray-500 cursor-pointer hover:text-black">
           Already registered?
         </p> */}
       </form>
     </div>
   </div>
 );
}

export default Booking;